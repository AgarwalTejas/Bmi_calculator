from tkinter import Tk
from gui import BMICalculatorApp
from database import init_db

def main():
    init_db()
    root = Tk()
    app = BMICalculatorApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
