import matplotlib.pyplot as plt
from datetime import datetime

def show_bmi_trend(records):
    if not records:
        return

    dates = [datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S") for row in records]
    bmis = [row[1] for row in records]

    plt.figure(figsize=(8, 5))
    plt.plot(dates, bmis, marker='o')
    plt.title("BMI Trend Over Time")
    plt.xlabel("Date")
    plt.ylabel("BMI")
    plt.grid(True)
    plt.tight_layout()
    plt.show()
