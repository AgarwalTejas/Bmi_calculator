import sqlite3
from datetime import datetime

DB_NAME = "bmi_data.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS bmi_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        weight REAL,
        height REAL,
        bmi REAL,
        category TEXT,
        date TEXT
    )
    """)
    conn.commit()
    conn.close()

def insert_record(username, weight, height, bmi, category):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO bmi_records (username, weight, height, bmi, category, date) VALUES (?, ?, ?, ?, ?, ?)",
              (username, weight, height, bmi, category, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    conn.close()

def fetch_user_records(username):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT date, bmi FROM bmi_records WHERE username = ? ORDER BY date", (username,))
    records = c.fetchall()
    conn.close()
    return records
