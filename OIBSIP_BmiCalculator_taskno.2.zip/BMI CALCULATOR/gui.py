import tkinter as tk
from tkinter import messagebox
from bmi_logic import calculate_bmi, categorize_bmi
from validation import is_valid_name, is_valid_height, is_valid_weight
from database import insert_record, fetch_user_records
from visualization import show_bmi_trend

class BMICalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BMI Calculator")

        # GUI Layout
        tk.Label(root, text="Username").grid(row=0, column=0)
        tk.Label(root, text="Weight (kg)").grid(row=1, column=0)
        tk.Label(root, text="Height (cm)").grid(row=2, column=0)

        self.name_entry = tk.Entry(root)
        self.weight_entry = tk.Entry(root)
        self.height_entry = tk.Entry(root)

        self.name_entry.grid(row=0, column=1)
        self.weight_entry.grid(row=1, column=1)
        self.height_entry.grid(row=2, column=1)

        self.result_label = tk.Label(root, text="", font=("Arial", 12), fg="blue")
        self.result_label.grid(row=4, columnspan=2)

        tk.Button(root, text="Calculate BMI", command=self.calculate_bmi).grid(row=3, column=0)
        tk.Button(root, text="Show Trend", command=self.show_trend).grid(row=3, column=1)

    def calculate_bmi(self):
        try:
            name = self.name_entry.get()
            weight = float(self.weight_entry.get())
            height = float(self.height_entry.get())

            if not is_valid_name(name):
                raise ValueError("Invalid name.")
            if not is_valid_weight(weight):
                raise ValueError("Weight out of range (20-300 kg).")
            if not is_valid_height(height):
                raise ValueError("Height out of range (80-250 cm).")

            bmi = calculate_bmi(weight, height)
            category = categorize_bmi(bmi)

            self.result_label.config(text=f"BMI: {bmi} ({category})")
            insert_record(name, weight, height, bmi, category)

        except ValueError as e:
            messagebox.showerror("Input Error", str(e))

    def show_trend(self):
        name = self.name_entry.get()
        if not is_valid_name(name):
            messagebox.showerror("Input Error", "Enter a valid username to view trend.")
            return

        records = fetch_user_records(name)
        if not records:
            messagebox.showinfo("No Data", "No records found for this user.")
        else:
            show_bmi_trend(records)
