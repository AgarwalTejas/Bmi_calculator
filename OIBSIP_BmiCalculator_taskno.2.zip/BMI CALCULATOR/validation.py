def is_valid_name(name):
    return bool(name.strip())

def is_valid_weight(weight):
    return 20 <= weight <= 300

def is_valid_height(height):
    return 80 <= height <= 250
